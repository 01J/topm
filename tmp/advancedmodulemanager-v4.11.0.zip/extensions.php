<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Advanced Module Manager
 * @version         4.11.0
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

function install(&$states, &$ext)
{
	$name = 'Advanced Module Manager';
	$alias = 'advancedmodules';
	$ext = $name . ' (admin component & system plugin)';

	// COMPONENT
	$states[] = installExtension($states, $alias, 'NoNumber ' . $name, 'component', array('link' => '', 'admin_menu_link' => ''));

	// SYSTEM PLUGIN
	$states[] = installExtension($states, $alias, 'System - NoNumber ' . $name, 'plugin', array('folder' => 'system'));
}

// Stuff to do after installation / update
function afterInstall(&$db)
{
	// main table
	$query = "CREATE TABLE IF NOT EXISTS `#__advancedmodules` (
		`moduleid` INT(11) UNSIGNED NOT NULL DEFAULT '0',
		`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
		`params` TEXT NOT NULL,
		PRIMARY KEY (`moduleid`)
	) DEFAULT CHARSET=utf8;";
	$db->setQuery($query);
	$db->execute();

	// add asset_id column
	$query = "SHOW COLUMNS FROM `" . $db->getPrefix() . "advancedmodules` LIKE 'asset_id'";
	$db->setQuery($query);
	$hasasset = $db->loadResult();
	if (!$hasasset)
	{
		$query = "ALTER TABLE `#__advancedmodules` ADD `asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `moduleid`";
		$db->setQuery($query);
		$db->execute();
	}

	$query = $db->getQuery(true);

	// hide admin menu
	$query->clear()
		->delete('#__menu')
		->where($db->quoteName('path') . ' = ' . $db->quote('advancedmodules'))
		->where($db->quoteName('type') . ' = ' . $db->quote('component'))
		->where($db->quoteName('client_id') . ' = 1');
	$db->setQuery($query);
	$db->execute();

	// remove initial menu assignment settings
	$query->clear()
		->update('#__advancedmodules as a')
		->set('a.params = ' . $db->quote(''))
		->where('a.params = ' . $db->quote('{"assignto_menuitems":0,"assignto_menuitems_selection":[]}'));
	$db->setQuery($query);
	$db->execute();

	// correct old keys and values
	$query->clear()
		->select('a.moduleid,a. params')
		->from('#__advancedmodules as a');
	$db->setQuery($query);
	$rows = $db->loadObjectList();
	foreach ($rows as $row)
	{
		if (empty($row->params))
		{
			continue;
		}

		if ($row->params['0'] != '{')
		{
			$row->params = str_replace('assignto_secscats', 'assignto_cats', $row->params);
			$row->params = str_replace('flexicontent', 'fc', $row->params);

			$params = JRegistryFormat::getInstance('INI')->stringToObject($row->params);
		}
		else
		{
			$params = json_decode($row->params);
		}

		// move tooltip to notes field
		if (isset($params->tooltip) && !empty($params->tooltip))
		{
			$query->clear()
				->update('#__modules as m')
				->set('m.note = ' . $db->quote($params->tooltip))
				->where('m.id = ' . (int) $row->moduleid);
			$db->setQuery($query);
			$db->execute();
			unset($params->tooltip);
		}

		// concatenate sef and non-sef url fields
		if (isset($params->assignto_urls_selection_sef))
		{
			$params->assignto_urls_selection = trim($params->assignto_urls_selection . "\n" . $params->assignto_urls_selection_sef);
			unset($params->assignto_urls_selection_sef);
			unset($params->show_url_field);
		}

		// set urls_regex value if assignto_urls is used
		if (!empty($params->assignto_urls) && !isset($params->assignto_urls_regex))
		{
			$params->assignto_urls_regex = 1;
		}

		foreach ($params as $k => &$v)
		{
			switch ($k)
			{
				case 'assignto_php_selection':
				case 'assignto_urls_selection':
				case 'assignto_ips_selection':
					$v = str_replace(array('\n', '\|'), array("\n", '|'), $v);
					break;
				case 'color':
					if ($v && $v != 'none' && $v['0'] != '#')
					{
						$v = '#' . strtolower($v);
					}
					break;
				case 'assignto_users_selection':
					$v = implode(',', explode('|', $v));
					break;
				default:
					if (
						(substr($k, -10) == '_selection' || substr($k, -4) == '_inc')
						&& !is_array($v)
					)
					{
						// convert | separated strings to arrays
						$v = explode('|', $v);
					}
					break;
			}
		}

		if (!empty($params->assignto_cats_selection))
		{
			foreach ($params->assignto_cats_selection as $key => $val)
			{
				if (strpos($val, ':') !== false)
				{
					$params->assignto_cats_selection[$key] = substr($val, strpos($val, ':') + 1);
				}
			}
		}

		$params = json_encode($params);

		if ($params == $row->params)
		{
			continue;
		}

		$query->clear()
			->update('#__advancedmodules as a')
			->set('a.params = ' . $db->quote($params))
			->where('a.moduleid = ' . (int) $row->moduleid);
		$db->setQuery($query);
		$db->execute();
	}
}
